
package presentation;

public class AutomataException extends Exception{
    public static final String construccion = "El metodo se encuentra en construccion";
    
    public AutomataException(String mensaje){
        super(mensaje);

    }
}
