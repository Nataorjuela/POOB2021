
public abstract class Accion{
    private static int acciones=1;
    
    private int id;
    protected String nombre;
    
    public Accion(String nombre){
        this.id=acciones;
        this.nombre=nombre;
        acciones++;
    }
    
    
    public abstract int dias() throws AccionExcepcion;
    
    /**Calcular el numero de dias estimados de una accion
     * Si hay problemas para calcular el numero de dias de una accion, se asume el maximo numero de dias de
     * sus subacciones, si es posible, o una semana (5 dias), en caso contrario.
     * @return 
     * */
    public abstract int diasEstimados();
    
    
    public abstract int dias(String nombre) throws AccionExcepcion;

    
}
