import java.util.ArrayList;

public class AccionCompuesta extends Accion{
    private ArrayList<Accion> acciones;
    
    public AccionCompuesta(String nombre){
        super(nombre);
        acciones= new ArrayList<Accion>();
    }
    
    public void adAccion(Accion a){
        acciones.add(a);
    }
    public int dias() throws AccionExcepcion{
        int cont=0;
        for(int i=0;i<acciones.size();i++){
            cont+=acciones.get(i).dias();
        }
        if(cont==0){
           throw new AccionExcepcion(AccionExcepcion.COMPUESTA_VACIA);
        }
        return cont;
    }
    public int diasEstimados(){
        int cont=0;
        try{
         int maximo=0;   
         for(int i=0;i<acciones.size();i++){
            if(maximo<acciones.get(i).dias()){ 
               maximo=acciones.get(i).dias();
            }
         }
         cont=maximo;
         if(cont==0){
           throw new AccionExcepcion(AccionExcepcion.COMPUESTA_VACIA);
         }
        }
        catch(AccionExcepcion e){cont=5;}
        return cont;
     }
    public int dias(String nombre) throws AccionExcepcion{
        int dias=0;
        int cont=0;
         for(int i=0;i<acciones.size();i++){
             try{
                dias=acciones.get(i).dias(nombre);
                cont++;
             }
          catch(AccionExcepcion e){}
        }
        if (cont==0){
            throw new AccionExcepcion(AccionExcepcion.NO_EXISTE_ACCION);
        }
        if (cont>1){
            throw new AccionExcepcion(AccionExcepcion.EXISTE_MAS_ACCION);
        }
        return dias;
    }
}
