
public class AccionExcepcion extends Exception{
   public static final String COMPUESTA_VACIA="Acccion compuesta vacia";
   public static final String  SIMPLE_SIN_DIAS="Actividad simple sin dias";
   public static final String  NO_EXISTE_ACCION="no existe una accion con ese nombre"; 
   public static final String  EXISTE_MAS_ACCION="existe más de una acción con el misma nombre";
    public AccionExcepcion(String mensaje){
        super(mensaje);
    }
}
