

public class AccionSimple extends Accion{
    private Integer dias;
    
    public AccionSimple(String nombre, Integer dias){
        super(nombre);
        this.dias=dias;
    }
    public int dias() throws AccionExcepcion{
        if(dias==null){
            throw new AccionExcepcion(AccionExcepcion.SIMPLE_SIN_DIAS);
        }
        else
        return dias.intValue();
    }
    public int diasEstimados(){
        return dias.intValue();
    }
    public int dias(String nombre) throws AccionExcepcion{
        System.out.println(nombre+"-"+this.nombre);
        if(!nombre.equals(this.nombre)){
          throw new AccionExcepcion(AccionExcepcion.NO_EXISTE_ACCION);
        }
        System.out.println("son iguales");
        return dias.intValue();

    }
}
