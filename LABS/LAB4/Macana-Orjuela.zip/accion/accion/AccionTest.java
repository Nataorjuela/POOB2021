import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;



public class AccionTest{
   
    private AccionCompuesta plan;
    private AccionCompuesta ai;
    private AccionCompuesta ae;
    private AccionCompuesta ac;
    private AccionSimple at;
    
    public AccionTest(){
    }


    @Before
    public void setUp(){
        plan=new AccionCompuesta("Proyecto");
        ai=new AccionCompuesta("Inicio");
        ae=new AccionCompuesta("Elaboracion");
        ac=new AccionCompuesta("Construccion");
        at=new AccionSimple("Transicion",10);
        ai.adAccion(new AccionSimple("Modelado de Negocio",5));
        ai.adAccion(new AccionSimple("Requerimientos",8));
        ae.adAccion(new AccionSimple("Diseño",10));
        ae.adAccion(new AccionSimple("Implementacion",10));        
        ac.adAccion(new AccionSimple("Implementacion",15));
        ac.adAccion(new AccionSimple("Pruebas",15));
        plan.adAccion(ai);
        plan.adAccion(ae);
        plan.adAccion(ac);
        plan.adAccion(at);
    }

    @After
    public void tearDown(){
    }
    
    @Test
    public void deberiaCalcularElNumeroDeDiasDeUnaAccion(){
        try {
           assertEquals(73,plan.dias());
        } catch (AccionExcepcion e){
            fail("Lanzó excepcion : "+e.getMessage());
        }    
    }    
         
    
    @Test
    public void deberiaLanzarExcepcionSiUnaAccionCompuestaNoTieneAccionesSimples(){
        ae.adAccion(new AccionCompuesta("Ajustes"));
        try { 
           assertEquals(73,plan.dias());
           fail("No lanzó excepcion");
        } catch (AccionExcepcion e) {
            assertEquals(AccionExcepcion.COMPUESTA_VACIA,e.getMessage());
        }    
    }    
    
    
    @Test
    public void deberiaLanzarExcepcionSiNoSeConocenLosDiasDeUnaAccionSimple(){
        ae.adAccion(new AccionSimple("Cierre",null));
        try { 
           assertEquals(73,plan.dias());
           fail("No lanza la excepcion");
        } catch (AccionExcepcion e) {
            assertEquals(AccionExcepcion.SIMPLE_SIN_DIAS,e.getMessage());
        }    
    }     
     @Test
    public void deberiaLanzarExcepcionSiNoExisteUnaAccionConEseNombre(){
        try { 
           assertEquals(73,plan.dias("PQR"));
           fail("No lanza la excepcion");
        } catch (AccionExcepcion e) {
            assertEquals(AccionExcepcion.NO_EXISTE_ACCION,e.getMessage());
        }    
     }     
    @Test
    public void deberiaLanzarExcepcionSiExisteMasDeUnaAccionConEseNombre(){
        try { 
           assertEquals(73,plan.dias("Implementacion"));
           fail("No lanza la excepcion");
        } catch (AccionExcepcion e) {
            assertEquals(AccionExcepcion.EXISTE_MAS_ACCION,e.getMessage());
        }    
    }  
}
