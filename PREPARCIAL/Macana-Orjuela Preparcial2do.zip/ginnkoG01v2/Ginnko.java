import java.util.HashMap;
import java.util.ArrayList;
public class Ginnko {

	private HashMap<String,Store> stores;
	private HashMap<String,Wholesaler> wholesalers;
	private HashMap<String,GlobalProduct> globalProducts;
	private HashMap<String,Category> categories;
	private HashMap<String,Zone> zones;
	private ArrayList<WholesalerAward> awards;
}
