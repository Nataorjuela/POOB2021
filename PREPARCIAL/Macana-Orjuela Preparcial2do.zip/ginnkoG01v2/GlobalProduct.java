 import java.util.HashMap;

public class GlobalProduct {
	private String name;
	private String image;
	private String description;
	private boolean isActive;
	private HashMap<String,Product> products;
}
