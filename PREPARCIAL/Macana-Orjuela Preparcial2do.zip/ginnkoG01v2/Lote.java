import java.time.LocalDate; 
/**
 * Write a description of class Lote here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Lote
{
    // instance variables - replace the example below with your own
    private int existenciasDisp;
    private LocalDate fechavencimeinto;
    /**
     * Constructor for objects of class Lote
     */
    public Lote()
    {
        
    }
    public int getExistencias(){
      return existenciasDisp;
    }
}
