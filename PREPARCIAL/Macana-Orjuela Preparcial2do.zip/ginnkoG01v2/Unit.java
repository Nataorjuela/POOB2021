 

public class Unit {

    private String reference;

    private boolean sold;

    private int unitPrice;

    public boolean sold() {
       return sold;
    }
    public int getUnitPrice(){
      return unitPrice;
    }
}
