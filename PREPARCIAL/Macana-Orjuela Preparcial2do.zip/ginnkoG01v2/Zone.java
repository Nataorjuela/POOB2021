 import java.util.HashMap;
public class Zone {
	private String city;
	private String location;
	private HashMap<Integer,Schedule> schedules;
}
