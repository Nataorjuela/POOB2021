 import java.time.LocalDate;
public class Product {
    private String name;
    private String presentation;
    private String description;
    private float weight;
    private int size;
    private int unitPrice;
    private LocalDate createdAt;
    private LocalDate updatedAt;
}
    

