 public class ProductLine {
	private int quantity;
	private int unitPrice;
	private Product product;
}
