import java.util.HashMap;
import java.time.LocalDate;

public class Wholesaler {
	private String name;
	private int commissionPercentage;
	private String logo;
	private LocalDate createdAt;
	private HashMap<String,Product> products;
}
