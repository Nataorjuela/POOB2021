 import java.util.ArrayList;
public class Zone {
	private String city;
	private String location;
	private ArrayList<Schedule> schedules;
}
