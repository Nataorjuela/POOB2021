
package Aplicacion;


public class Alimento {
     /*Inicio de declaracion de variables*/
    public String forma;                //guarda la ruta de la imagen donde se aloja la imagen de la fruta
    public int puntaje;
    public String color;
    public boolean visible;
    public int tamaño;
    /*Fin  de declaracion de variables*/
    
}
