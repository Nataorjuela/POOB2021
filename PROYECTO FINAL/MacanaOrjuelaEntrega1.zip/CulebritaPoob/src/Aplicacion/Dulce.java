
package Aplicacion;


public class Dulce extends Alimento{
    
}
