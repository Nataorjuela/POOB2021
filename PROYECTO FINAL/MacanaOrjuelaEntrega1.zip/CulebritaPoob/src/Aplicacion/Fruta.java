
package Aplicacion;


public class Fruta extends Alimento{
     
}
