/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aplicacion;

import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Snake {
    
    /*Inicio de declaracion de variables*/
    public int velocidad;
    public int tamaño;
    public boolean isVisible;
    public ArrayList<Cuadrado> cuadrados;
    /*Fin  de declaracion de variables*/
    
    public static void main(String[] args) {
        Snake juego= new Snake();
    }
    
}
