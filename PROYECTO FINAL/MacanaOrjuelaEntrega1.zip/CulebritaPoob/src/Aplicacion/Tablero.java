/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aplicacion;

/**
 *
 * @author user
 */
public class Tablero {
     /*Inicio de declaracion de variables*/
    public String color;
    public Alimento[] alimentos;
    public Snake culebra;
    public Snake culebra2;
    /*Fin  de declaracion de variables*/
    
}
