
package Aplicacion;

public class Informacion extends javax.swing.JFrame {
    
    // Variables declaration - do not modify                     
    private javax.swing.JLabel Fondo;
    private javax.swing.JLabel LabelPuntajeFruta;
    private javax.swing.JLabel jLabelNombreJugador;
    private javax.swing.JLabel jLabelPersonaje;
    private javax.swing.JLabel jLabelPuntajeDulce;
    private javax.swing.JLabel jLabelPuntajeFrutaArcoiris;
    private javax.swing.JLabel jLabelVeneno;
    String nombre;
    int fruta;
    int x;
    // End of variables declaration          
    
    public Informacion(int x,String nombre) {
        this.x=x;
        this.nombre=nombre;
        fruta=0;
        initComponents();
    }
    
   public void setFruta(){
        fruta=fruta+1;
        String numCadena= String.valueOf(fruta);
        LabelPuntajeFruta.setText(numCadena);
    }
    
    private void initComponents() {
        
        jLabelPersonaje = new javax.swing.JLabel();
        LabelPuntajeFruta = new javax.swing.JLabel();
        jLabelPuntajeFrutaArcoiris = new javax.swing.JLabel();
        jLabelPuntajeDulce = new javax.swing.JLabel();
        jLabelVeneno = new javax.swing.JLabel();
        jLabelNombreJugador = new javax.swing.JLabel();
        Fondo = new javax.swing.JLabel();
        
        this.setLocation(x,300);
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelPersonaje.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/serpientepeque.png"))); // NOI18N
        getContentPane().add(jLabelPersonaje, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 120, -1, -1));

        LabelPuntajeFruta.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        LabelPuntajeFruta.setForeground(new java.awt.Color(255, 255, 255));
        String numCadena= String.valueOf(fruta);
        LabelPuntajeFruta.setText(numCadena);
        getContentPane().add(LabelPuntajeFruta, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, 190, 40));

        jLabelPuntajeFrutaArcoiris.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabelPuntajeFrutaArcoiris.setForeground(new java.awt.Color(204, 0, 204));
        jLabelPuntajeFrutaArcoiris.setText("arcoriiiiriis");
        getContentPane().add(jLabelPuntajeFrutaArcoiris, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, 170, -1));

        jLabelPuntajeDulce.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabelPuntajeDulce.setForeground(new java.awt.Color(0, 0, 255));
        jLabelPuntajeDulce.setText("dulceeee");
        getContentPane().add(jLabelPuntajeDulce, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 270, 210, -1));

        jLabelVeneno.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabelVeneno.setForeground(new java.awt.Color(0, 0, 0));
        jLabelVeneno.setText("venenitooo");
        getContentPane().add(jLabelVeneno, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 310, -1, -1));

        jLabelNombreJugador.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 36)); // NOI18N
        jLabelNombreJugador.setForeground(new java.awt.Color(255, 0, 51));
        jLabelNombreJugador.setText(nombre);
        getContentPane().add(jLabelNombreJugador, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, 300, 50));

        Fondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/fondo.jpg"))); // NOI18N
        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    } 
         
}
