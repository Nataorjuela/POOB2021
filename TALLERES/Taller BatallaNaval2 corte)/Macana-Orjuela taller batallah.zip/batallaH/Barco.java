import java.util.ArrayList;

public class Barco extends Nodriza{
    private int numero;
    private ArrayList<Marino> marinos;
    
    /**
     * Constructor for objects of class Capsula
     */
     public Barco()
     {
        
     }
    public boolean esDebil(){
        boolean result=false;
        if (marinos.size()<5){
            result=true;
        }
        return result;
    }
}
