
import java.util.ArrayList;

public class Flota {
        private Tablero tablero;
	private String nombre;
	private ArrayList<Marino> marinos;
	private ArrayList<Maquina>maquinas;
	/**
	 * Este método mueve todas las máquinas la distancia definida
	 * El mundo tablero es circular. Longitud [0,180] Latitud [-90,90]. Coordenadas.
	 * @param dLon - avance en longitud
	 * @param dLat - avance en latitud
	 */
	public void avance(int dLon, int dLat){
	   for(int i=0;i<maquinas.size();i++){
	       maquinas.get(i).avance(dLon,dLat);
	   }
	}
	/**
	 * Consulta las máquinas débiles de una flota 
	 * Un barco es débil si tienen menos de cinco marinos; un avión, si no tiene piloto principal; 
	 * y un portaaviones si es un barco débil o alguno de sus aviones en aire es débil.
	 * @return 
	 */
	public ArrayList<Maquina> maquinasDebiles(){ 
	   ArrayList<Maquina> debiles=new ArrayList<Maquina>();
	   for(int i=0;i<maquinas.size();i++){
	       if(maquinas.get(i).esDebil()){
	          debiles.add(maquinas.get(i));
	       }
	   }
	   return debiles;
	}
	/**
	 * Mueve todas las máquinas que no son débiles paso a paso (uno a uno) hacia la posición a atacar indicada por (lon, lat)
	 * @param lon, longitud int
	 * @param lat, latitud int
	 */
	public void ataquen(int lon,int lat){
	    for(Maquina maquina:maquinas){
	       if(maquina.esDebil()==false){
	           for(int i =0;i<lon;i++){
	               maquina.avance(1,0);
	           }
	           for(int j=0;j<lat;j++){
	               maquina.avance(0,1);
	           }
	       }
	   }
	}
	public ArrayList <Maquina> destruidas(){
	  ArrayList<Maquina> destruidas=new ArrayList<Maquina>();  
	  for(int i=0;i<maquinas.size();i++){
	      if(maquinas.get(i).getDestruida()){
	        destruidas.add(maquinas.get(i));
	       }
	    }
	    return destruidas;
	 }
}
