 import java.util.ArrayList;

public class Maquina {
    private Ubicacion ubicacion;
    private ArrayList<Maquina>maquinas;
    protected boolean destruida;
    public Maquina(){
       destruida=false; 
    }
    public void avance(int dlong,int dlat){
       ubicacion.avance(dlong,dlat);
     }
    public boolean esDebil(){
        return false;
     }
    public void destruir(){
        destruida=true;
    }
    public boolean getDestruida(){
        return destruida;
    }
}
