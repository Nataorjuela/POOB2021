
public class Marino {
	private String nombre;
	private int rango;
	private boolean autoDestruir;
	public Marino(){
	   
	}
	public boolean autoDestruir(){
	    autoDestruir=true;
	    System.out.println("Causa:En riesgo");
            return autoDestruir;
        }
    }
