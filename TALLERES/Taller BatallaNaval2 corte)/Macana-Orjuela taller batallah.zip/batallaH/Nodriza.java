
/**
 * Write a description of class Nodriza here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Nodriza extends Maquina
{
   protected int x;
   protected int y;
   /**
     * Constructor for objects of class Nodriza
     */
    public Nodriza(){
        
   }
   public void darDireccion(int p1, int p2){
       x=p1;
       y=p2;
       
   }
}
