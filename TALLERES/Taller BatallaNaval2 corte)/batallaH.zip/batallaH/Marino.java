 

public class Marino {
	private String nombre;
	private int rango;
}
