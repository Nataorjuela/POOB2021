 

public class Ubicacion {
    private int longitud;
    private int latitud;
    public void avance(int dlong,int dlat){
        longitud+=dlong;
        latitud+=dlat;
    }
}
