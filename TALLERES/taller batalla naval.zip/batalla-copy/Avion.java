public class Avion {
	private String placa;
	private boolean enAire;
	private Posicion ubicacion;
	private Marino piloto;
	private Marino copiloto;

}
