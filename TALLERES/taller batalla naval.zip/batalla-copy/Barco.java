import java.util.Collection;

public class Barco {

	private int numero;

	private Posicion ubicacion;

	private Collection<Marino> marinos;

}
